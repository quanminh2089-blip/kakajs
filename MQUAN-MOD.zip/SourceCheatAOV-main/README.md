# Thông Tin

## Môi trường build Android

- Android Gradle Plugin: 8.6.1
- Gradle Wrapper: 8.7
- JDK: 17
- Android SDK: API 35 (Android 15)
- Android NDK: 28.2.13676358
- ABI đóng gói: `arm64-v8a`, `armeabi-v7a`

Các thư viện native cần được build lại bằng NDK đã nêu để nhận căn chỉnh 16 KB mặc định của NDK r28. Cấu hình này chỉ nâng bộ công cụ và đóng gói; chưa xác minh các hook/địa chỉ native với phiên bản game cụ thể.
<p align="center">
  <a href="https://discord.gg/79ucHtZn5w"><img alt="Discord" title="Discord" src="https://img.shields.io/badge/-Discord-7289DA?style=for-the-badge&logo=discord&logoColor=white"/></a>
  <a href="https://www.youtube.com/c/ImTienNguyenZ"><img alt="Youtube" title="Youtube" src="https://img.shields.io/badge/-Youtube-FF0000?style=for-the-badge&logo=youtube&logoColor=white"/></a>
  <a href="https://playerduo.net/tientinycute"><img alt="PlayerDuo" title="PlayerDuo" src="https://img.shields.io/badge/-PlayerDuo-ff7389?style=for-the-badge&logo=kofi&logoColor=white"/></a>
<a href="https://github.com/ImTienNguyenZ?tab=repositories&sort=stargazers">
    <img alt="total stars" title="Total stars on GitHub" src="https://custom-icon-badges.demolab.com/github/stars/ImTienNguyenZ?color=B8B92B&style=for-the-badge&labelColor=959532&logo=star"/></a>
   <a href="https://github.com/ImTienNguyenZ"><img alt="followers" title="Follow me on Github" src="https://img.shields.io/github/followers/ImTienNguyenZ?color=236ad3&style=for-the-badge&logo=github&label=Follow"/></a>
 </p>
ModMenu Liên Quân Mobile, Hỗ Trợ Android 6+ - 13.
Được Dựa Trên Project Của LGL Modder, Và 1 Số Nguồn Khác...
Mã Nguồn Được Share Hoàn Toàn Miễn Phí, Vui Lòng Không Mang Bán Lại Dưới Mọi Hình Thức!

# Chức Năng
- [x] Hack Map
- [x] Cam Xa
- [x] Unlock Fps
- [x] Ẩn Tên
- [x] Hủy Hồi Chiêu
- [x] Show Info Hero
- [x] Show Lịch Sử Đấu
- [ ] Bypass
``Đây Là Đồ Miễn Phí Nên Ae Đừng Đòi Hỏi Gì Nhé!!``

# Demo
![](https://i.ibb.co/86hGvqP/ezgif-com-video-to-gif.gif)

# Khác
- Chân Thành Cảm Ơn LGL Modder Team https://github.com/LGLTeam/Android-Mod-Menu
- Kiểm Tra Update Source Tại: https://github.com/ImTienNguyenZ/SourceCheatLienQuan/releases 
`Và Xem Phiên Bản Game Để Download Nhé`
